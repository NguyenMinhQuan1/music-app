# github-music-app
An Android project written in pure Java with a purpose to stream music online. Database server is Firebase database and storage.
# Some screenshots of the app
Login Screen

![image](https://user-images.githubusercontent.com/71256843/118416723-36e4f600-b6db-11eb-9231-4c0f54fe5f5e.png)

Home Screen

![image](https://user-images.githubusercontent.com/71256843/118416734-45331200-b6db-11eb-9361-288959006839.png)

Category Screen

![image](https://user-images.githubusercontent.com/71256843/118416758-672c9480-b6db-11eb-8e24-48e546932796.png)

My Playlist Screen

![image](https://user-images.githubusercontent.com/71256843/118416808-9cd17d80-b6db-11eb-93e1-bc506bdffdd0.png)

Artist Screen

![image](https://user-images.githubusercontent.com/71256843/118416821-ac50c680-b6db-11eb-862a-d8ff60c74ade.png)

Search Screen

![image](https://user-images.githubusercontent.com/71256843/118416828-b2df3e00-b6db-11eb-9316-8b1dd2abaa57.png)


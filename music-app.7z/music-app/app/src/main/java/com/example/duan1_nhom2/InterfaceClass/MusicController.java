package com.example.duan1_nhom2.InterfaceClass;

public interface MusicController {
    void mcSkipToPrevious();
    void mcPlayAndPause();
    void mcSkipToNext();
    void mcOnStart();
    void mcOnPause();
}

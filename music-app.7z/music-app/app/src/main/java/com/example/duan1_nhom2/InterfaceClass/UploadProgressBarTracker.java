package com.example.duan1_nhom2.InterfaceClass;

public interface UploadProgressBarTracker {
    void updateProgressBar(int progress);
}
